import React from 'react'

export default function UpdateProfile() {
  return (
    <div>
      
    </div>
  )
}
