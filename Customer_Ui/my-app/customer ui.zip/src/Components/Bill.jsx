import React from 'react'

export default function deleteVehicle() {
  return (
    <div>
      bill
    </div>
  )
}
